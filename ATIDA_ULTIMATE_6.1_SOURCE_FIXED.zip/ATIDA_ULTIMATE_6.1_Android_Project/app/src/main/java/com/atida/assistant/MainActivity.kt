package com.atida.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.fragment.app.FragmentActivity
import androidx.biometric.BiometricPrompt
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.OutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import java.util.concurrent.Executor

class MainActivity : FragmentActivity() {
    private lateinit var webView: WebView
    private lateinit var mainExecutor: Executor
    private var pendingMusicScan = false
    private var mediaPlayer: MediaPlayer? = null
    private var pendingExportBytes: ByteArray? = null
    private var pendingExportName: String = "atida-file.txt"

    companion object {
        private const val REQUEST_CAMERA = 41
        private const val REQUEST_SPEECH = 42
        private const val REQUEST_AUDIO_PERMISSION = 43
        private const val REQUEST_MIC_PERMISSION = 40
        private const val REQUEST_SAVE_FILE = 44
        private const val REQUEST_SAVE_ZIP = 45
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mainExecutor = ContextCompat.getMainExecutor(this)

        webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.mediaPlaybackRequiresUserGesture = true
        webView.settings.allowFileAccess = true
        webView.settings.allowContentAccess = true
        webView.addJavascriptInterface(AtidaBridge(), "NativeATIDA")
        webView.webViewClient = WebViewClient()
        webView.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(request: PermissionRequest) {
                runOnUiThread {
                    val audioGranted = ContextCompat.checkSelfPermission(
                        this@MainActivity, Manifest.permission.RECORD_AUDIO
                    ) == PackageManager.PERMISSION_GRANTED
                    val resources = request.resources.filter {
                        it == PermissionRequest.RESOURCE_AUDIO_CAPTURE && audioGranted
                    }.toTypedArray()
                    if (resources.isNotEmpty()) request.grant(resources) else request.deny()
                }
            }
        }
        setContentView(webView)
        webView.loadUrl("file:///android_asset/index.html")
    }

    private inner class AtidaBridge {
        @JavascriptInterface fun openCamera() {
            runOnUiThread {
                if (ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(this@MainActivity, arrayOf(Manifest.permission.CAMERA), REQUEST_CAMERA)
                } else launchCamera()
            }
        }
        @JavascriptInterface fun authenticate() { runOnUiThread { showBiometricPrompt() } }
        @JavascriptInterface fun startVoiceInput() { runOnUiThread { launchSpeechRecognition() } }
        @JavascriptInterface fun loadDeviceMusic() { runOnUiThread { requestOrLoadMusic() } }
        @JavascriptInterface fun playDeviceTrack(uri: String) { runOnUiThread { playTrack(uri) } }
        @JavascriptInterface fun pauseDeviceTrack() { runOnUiThread { try { if (mediaPlayer?.isPlaying == true) mediaPlayer?.pause(); runJs("window.onDeviceMusicPlayback(false);") } catch (_: Exception) {} } }
        @JavascriptInterface fun resumeDeviceTrack() { runOnUiThread { try { mediaPlayer?.start(); runJs("window.onDeviceMusicPlayback(true);") } catch (_: Exception) { runJs("window.onDeviceMusicError('Playback could not resume. Choose the song again.');") } } }
        @JavascriptInterface fun stopDeviceTrack() { runOnUiThread { releasePlayer(); runJs("window.onDeviceMusicPlayback(false);") } }
        @JavascriptInterface fun getDeviceInfo() { runOnUiThread { sendDeviceInfo() } }
        @JavascriptInterface fun openSystemUpdateSettings() { runOnUiThread { openUpdateSettings() } }
        @JavascriptInterface fun saveTextFile(name: String, mime: String, content: String) {
            runOnUiThread {
                pendingExportName = name.take(120).ifBlank { "atida-file.txt" }
                pendingExportBytes = content.toByteArray(Charsets.UTF_8)
                val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = mime.ifBlank { "text/plain" }
                    putExtra(Intent.EXTRA_TITLE, pendingExportName)
                }
                try { startActivityForResult(intent, REQUEST_SAVE_FILE) }
                catch (_: Exception) { runJs("window.onAtidaFileSaved(${JSONObject.quote(pendingExportName)},false);") }
            }
        }
        @JavascriptInterface fun createZip(name: String, entriesJson: String) {
            runOnUiThread {
                try {
                    val entries = JSONArray(entriesJson)
                    val bytes = ByteArrayOutputStream()
                    ZipOutputStream(bytes).use { zip ->
                        for (i in 0 until entries.length()) {
                            val item = entries.getJSONObject(i)
                            val entryName = item.optString("name", "file-${i + 1}.txt").replace("..", "_").trimStart('/', '\\')
                            zip.putNextEntry(ZipEntry(entryName.ifBlank { "file-${i + 1}.txt" }))
                            zip.write(item.optString("content", "").toByteArray(Charsets.UTF_8))
                            zip.closeEntry()
                        }
                    }
                    pendingExportName = name.take(120).ifBlank { "atida-project.zip" }
                    pendingExportBytes = bytes.toByteArray()
                    val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = "application/zip"
                        putExtra(Intent.EXTRA_TITLE, pendingExportName)
                    }
                    startActivityForResult(intent, REQUEST_SAVE_ZIP)
                } catch (e: Exception) {
                    runJs("window.onAtidaFileSaved(${JSONObject.quote(name)},false);")
                }
            }
        }
        @JavascriptInterface fun openImageSearch(query: String) {
            runOnUiThread {
                val url = "https://www.google.com/search?tbm=isch&q=" + Uri.encode(query)
                try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
                catch (_: Exception) { runJs("window.onAtidaFileSaved('image search',false);") }
            }
        }
    }

    private fun hasAudioPermission(): Boolean {
        val permission = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE
        return ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED
    }

    private fun requestOrLoadMusic() {
        if (!hasAudioPermission()) {
            pendingMusicScan = true
            val permission = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE
            ActivityCompat.requestPermissions(this, arrayOf(permission), REQUEST_AUDIO_PERMISSION)
        } else loadDeviceMusic()
    }

    private fun loadDeviceMusic() {
        try {
            val rows = JSONArray()
            val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
            val projection = arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.DURATION)
            val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0"
            contentResolver.query(collection, projection, selection, null, "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC")?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                val artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
                val durationCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idCol)
                    val itemUri = Uri.withAppendedPath(collection, id.toString())
                    rows.put(JSONObject().apply {
                        put("id", id.toString())
                        put("title", cursor.getString(titleCol) ?: "Unknown title")
                        put("artist", cursor.getString(artistCol) ?: "Unknown artist")
                        put("duration", cursor.getLong(durationCol))
                        put("uri", itemUri.toString())
                        put("browser", false)
                    })
                }
            }
            runJs("window.onDeviceMusicLoaded(${JSONObject.quote(rows.toString())});")
        } catch (e: Exception) {
            runJs("window.onDeviceMusicError(${JSONObject.quote("Could not scan audio library: ${e.message ?: "unknown error"}")});")
        }
    }

    private fun playTrack(uriText: String) {
        try {
            releasePlayer()
            val player = MediaPlayer()
            mediaPlayer = player
            player.setDataSource(this, Uri.parse(uriText))
            player.setOnPreparedListener { it.start(); runJs("window.onDeviceMusicPlayback(true);") }
            player.setOnCompletionListener { runJs("window.onDeviceMusicPlayback(false);window.onDeviceMusicEnded();") }
            player.setOnErrorListener { _, _, _ -> runJs("window.onDeviceMusicError('Android could not play this audio file.');window.onDeviceMusicPlayback(false);"); true }
            player.prepareAsync()
        } catch (e: Exception) {
            runJs("window.onDeviceMusicError(${JSONObject.quote("Could not start audio: ${e.message ?: "unsupported file"}")});")
        }
    }

    private fun releasePlayer() {
        try { mediaPlayer?.stop() } catch (_: Exception) {}
        try { mediaPlayer?.release() } catch (_: Exception) {}
        mediaPlayer = null
    }

    private fun sendDeviceInfo() {
        val info = JSONObject().apply {
            put("manufacturer", Build.MANUFACTURER ?: "Android")
            put("deviceModel", Build.MODEL ?: "Unknown model")
            put("platform", "Android")
            put("osVersion", Build.VERSION.RELEASE ?: "Unknown")
            put("sdkInt", Build.VERSION.SDK_INT)
            put("securityPatch", if (Build.VERSION.SDK_INT >= 23) Build.VERSION.SECURITY_PATCH else "Unavailable")
            put("compatibility", if (Build.VERSION.SDK_INT >= 23) "Android API ${Build.VERSION.SDK_INT}; compatible with this app's minimum API 23" else "Older Android version; compatibility not confirmed")
        }
        runJs("window.onAtidaDeviceInfo($info);")
    }

    private fun openUpdateSettings() {
        val intents = listOf(Intent("android.settings.SYSTEM_UPDATE_SETTINGS"), Intent(Settings.ACTION_SETTINGS))
        for (intent in intents) {
            try { startActivity(intent); return } catch (_: Exception) {}
        }
        runJs("window.onAtidaDeviceInfo({compatibility:'Could not open system update settings on this device.'});")
    }

    private fun launchCamera() {
        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        if (intent.resolveActivity(packageManager) != null) try { startActivityForResult(intent, REQUEST_CAMERA) }
        catch (_: Exception) { runJs("document.getElementById('visionStatus').textContent='Camera could not be opened on this device.';") }
        else runJs("document.getElementById('visionStatus').textContent='No camera app is available.';")
    }

    private fun showBiometricPrompt() {
        val promptInfo = try {
            BiometricPrompt.PromptInfo.Builder().setTitle("Verify your identity")
                .setSubtitle("Use an enrolled biometric or your Android screen lock")
                .setAllowedAuthenticators(androidx.biometric.BiometricManager.Authenticators.BIOMETRIC_WEAK or androidx.biometric.BiometricManager.Authenticators.DEVICE_CREDENTIAL).build()
        } catch (_: Exception) { runJs("window.onBiometricResult(false,'Biometric prompt is unavailable on this Android version.');"); return }
        val prompt = BiometricPrompt(this, mainExecutor, object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) { runJs("window.onBiometricResult(true,'Android authentication succeeded.');") }
            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) { runJs("window.onBiometricResult(false,${JSONObject.quote(errString.toString())});") }
            override fun onAuthenticationFailed() { runJs("window.onBiometricResult(false,'Biometric not recognised. Android may offer your device credential.');") }
        })
        try { prompt.authenticate(promptInfo) } catch (_: Exception) { runJs("window.onBiometricResult(false,'Could not start Android authentication. Check that a screen lock or biometric is enrolled.');") }
    }

    private fun launchSpeechRecognition() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), REQUEST_MIC_PERMISSION)
            runJs("document.getElementById('hearingStatus').textContent='Allow microphone access, then tap Listen now again.';")
            return
        }
        val intent = Intent(android.speech.RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE_MODEL, android.speech.RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE, "en-GB")
            putExtra(android.speech.RecognizerIntent.EXTRA_PROMPT, "ATIDA is listening")
            putExtra(android.speech.RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
        try { startActivityForResult(intent, REQUEST_SPEECH) } catch (_: Exception) { runJs("window.onNativeSpeech('');") }
    }

    @Deprecated("Legacy result API retained for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_CAMERA) {
            if (resultCode == Activity.RESULT_OK) {
                val bitmap = data?.extras?.get("data") as? Bitmap
                if (bitmap != null) { val output = ByteArrayOutputStream(); bitmap.compress(Bitmap.CompressFormat.JPEG, 78, output); val encoded = Base64.encodeToString(output.toByteArray(), Base64.NO_WRAP); runJs("window.onNativePhoto('$encoded');") }
                else runJs("document.getElementById('visionStatus').textContent='Camera returned no preview image.';")
            } else runJs("document.getElementById('visionStatus').textContent='Camera capture cancelled.';")
        } else if (requestCode == REQUEST_SPEECH) {
            val matches = if (resultCode == Activity.RESULT_OK) data?.getStringArrayListExtra(android.speech.RecognizerIntent.EXTRA_RESULTS) else null
            val spoken = matches?.firstOrNull()
            runJs(if (!spoken.isNullOrBlank()) "window.onNativeSpeech(${JSONObject.quote(spoken)});" else "window.onNativeSpeech('');")
        } else if (requestCode == REQUEST_SAVE_FILE || requestCode == REQUEST_SAVE_ZIP) {
            val bytes = pendingExportBytes
            val name = pendingExportName
            pendingExportBytes = null
            if (resultCode == Activity.RESULT_OK && data?.data != null && bytes != null) {
                val saved = try { contentResolver.openOutputStream(data.data!!)?.use { it.write(bytes) }; true } catch (_: Exception) { false }
                runJs("window.onAtidaFileSaved(${JSONObject.quote(name)},${saved});")
            } else {
                runJs("window.onAtidaFileSaved(${JSONObject.quote(name)},false);")
            }
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_CAMERA) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) launchCamera()
            else runJs("document.getElementById('visionStatus').textContent='Camera permission was denied.';")
        } else if (requestCode == REQUEST_AUDIO_PERMISSION) {
            pendingMusicScan = false
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) loadDeviceMusic()
            else runJs("window.onDeviceMusicError('Music library permission was denied. You can still add files manually in the browser preview.');")
        }
    }

    private fun runJs(script: String) { if (::webView.isInitialized) webView.post { webView.evaluateJavascript(script, null) } }
    override fun onDestroy() { releasePlayer(); super.onDestroy() }
    override fun onBackPressed() { if (this::webView.isInitialized && webView.canGoBack()) webView.goBack() else super.onBackPressed() }
}
