plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }

android {
    namespace = "com.atida.assistant"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.atida.assistant"
        minSdk = 23
        targetSdk = 35
        versionCode = 2
        versionName = "6.1"
    }
}

dependencies {
    implementation("androidx.activity:activity-ktx:1.9.3")
    implementation("androidx.fragment:fragment-ktx:1.8.5")
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.biometric:biometric:1.1.0")
}
