package com.atida.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.fragment.app.FragmentActivity
import androidx.biometric.BiometricPrompt
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executor

class MainActivity : FragmentActivity() {
    private lateinit var webView: WebView
    private lateinit var mainExecutor: Executor
    private var pendingMusicScan = false
    private var mediaPlayer: MediaPlayer? = null

    companion object {
        private const val REQUEST_CAMERA = 41
        private const val REQUEST_SPEECH = 42
        private const val REQUEST_AUDIO_PERMISSION = 43
        private const val REQUEST_MIC_PERMISSION = 40
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mainExecutor = ContextCompat.getMainExecutor(this)

        webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.mediaPlaybackRequiresUserGesture = true
        webView.settings.allowFileAccess = true
        webView.settings.allowContentAccess = true
        webView.addJavascriptInterface(AtidaBridge(), "NativeATIDA")
        webView.webViewClient = WebViewClient()
        webView.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(request: PermissionRequest) {
                runOnUiThread {
                    val audioGranted = ContextCompat.checkSelfPermission(
                        this@MainActivity, Manifest.permission.RECORD_AUDIO
                    ) == PackageManager.PERMISSION_GRANTED
                    val resources = request.resources.filter {
                        it == PermissionRequest.RESOURCE_AUDIO_CAPTURE && audioGranted
                    }.toTypedArray()
                    if (resources.isNotEmpty()) request.grant(resources) else request.deny()
                }
            }
        }
        setContentView(webView)
        webView.loadUrl("file:///android_asset/index.html")
    }

    private inner class AtidaBridge {
        @JavascriptInterface fun openCamera() {
            runOnUiThread {
                if (ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(this@MainActivity, arrayOf(Manifest.permission.CAMERA), REQUEST_CAMERA)
                } else launchCamera()
            }
        }
        @JavascriptInterface fun authenticate() { runOnUiThread { showBiometricPrompt() } }
        @JavascriptInterface fun startVoiceInput() { runOnUiThread { launchSpeechRecognition() } }
        @JavascriptInterface fun loadDeviceMusic() { runOnUiThread { requestOrLoadMusic() } }
        @JavascriptInterface fun playDeviceTrack(uri: String) { runOnUiThread { playTrack(uri) } }
        @JavascriptInterface fun pauseDeviceTrack() { runOnUiThread { try { if (mediaPlayer?.isPlaying == true) mediaPlayer?.pause(); runJs("window.onDeviceMusicPlayback(false);") } catch (_: Exception) {} } }
        @JavascriptInterface fun resumeDeviceTrack() { runOnUiThread { try { mediaPlayer?.start(); runJs("window.onDeviceMusicPlayback(true);") } catch (_: Exception) { runJs("window.onDeviceMusicError('Playback could not resume. Choose the song again.');") } } }
        @JavascriptInterface fun stopDeviceTrack() { runOnUiThread { releasePlayer(); runJs("window.onDeviceMusicPlayback(false);") } }
        @JavascriptInterface fun getDeviceInfo() { runOnUiThread { sendDeviceInfo() } }
        @JavascriptInterface fun openSystemUpdateSettings() { runOnUiThread { openUpdateSettings() } }

        // ATIDA's web interface runs from file://, so its relative fetch() URLs
        // cannot reach the Termux service. Keep networking native and restricted
        // to the loopback server on this phone.
        @JavascriptInterface fun sendAIRequest(path: String, payload: String, requestId: String) {
            if (path != "/api/health" && path != "/api/chat") {
                deliverAIResponse(requestId, 400, "{\"error\":\"Unsupported local API path\"}")
                return
            }
            Thread {
                var connection: HttpURLConnection? = null
                try {
                    connection = (URL("http://127.0.0.1:8000$path").openConnection() as HttpURLConnection).apply {
                        connectTimeout = 5000
                        readTimeout = if (path == "/api/chat") 180000 else 5000
                        requestMethod = if (path == "/api/chat") "POST" else "GET"
                        setRequestProperty("Accept", "application/json")
                        if (path == "/api/chat") {
                            doOutput = true
                            setRequestProperty("Content-Type", "application/json; charset=utf-8")
                            outputStream.use { it.write(payload.toByteArray(Charsets.UTF_8)) }
                        }
                    }
                    val status = connection.responseCode
                    val stream = if (status in 200..299) connection.inputStream else connection.errorStream
                    val body = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: "{}"
                    deliverAIResponse(requestId, status, body)
                } catch (e: Exception) {
                    val error = JSONObject().put("error", e.message ?: "Could not reach ATIDA's local server").toString()
                    deliverAIResponse(requestId, 0, error)
                } finally {
                    connection?.disconnect()
                }
            }.start()
        }

        private fun deliverAIResponse(requestId: String, status: Int, body: String) {
            val id = JSONObject.quote(requestId)
            val safeBody = JSONObject.quote(body)
            runJs("window.onNativeAIResponse && window.onNativeAIResponse($id,$status,$safeBody);")
        }
    }

    private fun hasAudioPermission(): Boolean {
        val permission = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE
        return ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED
    }

    private fun requestOrLoadMusic() {
        if (!hasAudioPermission()) {
            pendingMusicScan = true
            val permission = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE
            ActivityCompat.requestPermissions(this, arrayOf(permission), REQUEST_AUDIO_PERMISSION)
        } else loadDeviceMusic()
    }

    private fun loadDeviceMusic() {
        try {
            val rows = JSONArray()
            val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
            val projection = arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.DURATION)
            val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0"
            contentResolver.query(collection, projection, selection, null, "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC")?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                val artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
                val durationCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idCol)
                    val itemUri = Uri.withAppendedPath(collection, id.toString())
                    rows.put(JSONObject().apply {
                        put("id", id.toString())
                        put("title", cursor.getString(titleCol) ?: "Unknown title")
                        put("artist", cursor.getString(artistCol) ?: "Unknown artist")
                        put("duration", cursor.getLong(durationCol))
                        put("uri", itemUri.toString())
                        put("browser", false)
                    })
                }
            }
            runJs("window.onDeviceMusicLoaded(${JSONObject.quote(rows.toString())});")
        } catch (e: Exception) {
            runJs("window.onDeviceMusicError(${JSONObject.quote("Could not scan audio library: ${e.message ?: "unknown error"}")});")
        }
    }

    private fun playTrack(uriText: String) {
        try {
            releasePlayer()
            val player = MediaPlayer()
            mediaPlayer = player
            player.setDataSource(this, Uri.parse(uriText))
            player.setOnPreparedListener { it.start(); runJs("window.onDeviceMusicPlayback(true);") }
            player.setOnCompletionListener { runJs("window.onDeviceMusicPlayback(false);window.onDeviceMusicEnded();") }
            player.setOnErrorListener { _, _, _ -> runJs("window.onDeviceMusicError('Android could not play this audio file.');window.onDeviceMusicPlayback(false);"); true }
            player.prepareAsync()
        } catch (e: Exception) {
            runJs("window.onDeviceMusicError(${JSONObject.quote("Could not start audio: ${e.message ?: "unsupported file"}")});")
        }
    }

    private fun releasePlayer() {
        try { mediaPlayer?.stop() } catch (_: Exception) {}
        try { mediaPlayer?.release() } catch (_: Exception) {}
        mediaPlayer = null
    }

    private fun sendDeviceInfo() {
        val info = JSONObject().apply {
            put("manufacturer", Build.MANUFACTURER ?: "Android")
            put("deviceModel", Build.MODEL ?: "Unknown model")
            put("platform", "Android")
            put("osVersion", Build.VERSION.RELEASE ?: "Unknown")
            put("sdkInt", Build.VERSION.SDK_INT)
            put("securityPatch", if (Build.VERSION.SDK_INT >= 23) Build.VERSION.SECURITY_PATCH else "Unavailable")
            put("compatibility", if (Build.VERSION.SDK_INT >= 23) "Android API ${Build.VERSION.SDK_INT}; compatible with this app's minimum API 23" else "Older Android version; compatibility not confirmed")
        }
        runJs("window.onAtidaDeviceInfo($info);")
    }

    private fun openUpdateSettings() {
        val intents = listOf(Intent("android.settings.SYSTEM_UPDATE_SETTINGS"), Intent(Settings.ACTION_SETTINGS))
        for (intent in intents) {
            try { startActivity(intent); return } catch (_: Exception) {}
        }
        runJs("window.onAtidaDeviceInfo({compatibility:'Could not open system update settings on this device.'});")
    }

    private fun launchCamera() {
        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        if (intent.resolveActivity(packageManager) != null) try { startActivityForResult(intent, REQUEST_CAMERA) }
        catch (_: Exception) { runJs("document.getElementById('visionStatus').textContent='Camera could not be opened on this device.';") }
        else runJs("document.getElementById('visionStatus').textContent='No camera app is available.';")
    }

    private fun showBiometricPrompt() {
        val promptInfo = try {
            BiometricPrompt.PromptInfo.Builder().setTitle("Verify your identity")
                .setSubtitle("Use an enrolled biometric or your Android screen lock")
                .setAllowedAuthenticators(androidx.biometric.BiometricManager.Authenticators.BIOMETRIC_WEAK or androidx.biometric.BiometricManager.Authenticators.DEVICE_CREDENTIAL).build()
        } catch (_: Exception) { runJs("window.onBiometricResult(false,'Biometric prompt is unavailable on this Android version.');"); return }
        val prompt = BiometricPrompt(this, mainExecutor, object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) { runJs("window.onBiometricResult(true,'Android authentication succeeded.');") }
            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) { runJs("window.onBiometricResult(false,${JSONObject.quote(errString.toString())});") }
            override fun onAuthenticationFailed() { runJs("window.onBiometricResult(false,'Biometric not recognised. Android may offer your device credential.');") }
        })
        try { prompt.authenticate(promptInfo) } catch (_: Exception) { runJs("window.onBiometricResult(false,'Could not start Android authentication. Check that a screen lock or biometric is enrolled.');") }
    }

    private fun launchSpeechRecognition() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), REQUEST_MIC_PERMISSION)
            runJs("document.getElementById('hearingStatus').textContent='Allow microphone access, then tap Listen now again.';")
            return
        }
        val intent = Intent(android.speech.RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE_MODEL, android.speech.RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE, "en-GB")
            putExtra(android.speech.RecognizerIntent.EXTRA_PROMPT, "ATIDA is listening")
            putExtra(android.speech.RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
        try { startActivityForResult(intent, REQUEST_SPEECH) } catch (_: Exception) { runJs("window.onNativeSpeech('');") }
    }

    @Deprecated("Legacy result API retained for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_CAMERA) {
            if (resultCode == Activity.RESULT_OK) {
                val bitmap = data?.extras?.get("data") as? Bitmap
                if (bitmap != null) { val output = ByteArrayOutputStream(); bitmap.compress(Bitmap.CompressFormat.JPEG, 78, output); val encoded = Base64.encodeToString(output.toByteArray(), Base64.NO_WRAP); runJs("window.onNativePhoto('$encoded');") }
                else runJs("document.getElementById('visionStatus').textContent='Camera returned no preview image.';")
            } else runJs("document.getElementById('visionStatus').textContent='Camera capture cancelled.';")
        } else if (requestCode == REQUEST_SPEECH) {
            val matches = if (resultCode == Activity.RESULT_OK) data?.getStringArrayListExtra(android.speech.RecognizerIntent.EXTRA_RESULTS) else null
            val spoken = matches?.firstOrNull()
            runJs(if (!spoken.isNullOrBlank()) "window.onNativeSpeech(${JSONObject.quote(spoken)});" else "window.onNativeSpeech('');")
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_CAMERA) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) launchCamera()
            else runJs("document.getElementById('visionStatus').textContent='Camera permission was denied.';")
        } else if (requestCode == REQUEST_AUDIO_PERMISSION) {
            pendingMusicScan = false
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) loadDeviceMusic()
            else runJs("window.onDeviceMusicError('Music library permission was denied. You can still add files manually in the browser preview.');")
        }
    }

    private fun runJs(script: String) { if (::webView.isInitialized) webView.post { webView.evaluateJavascript(script, null) } }
    override fun onDestroy() { releasePlayer(); super.onDestroy() }
    override fun onBackPressed() { if (this::webView.isInitialized && webView.canGoBack()) webView.goBack() else super.onBackPressed() }
}
